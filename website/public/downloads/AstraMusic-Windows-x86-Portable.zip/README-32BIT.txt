==================================================
ASTRA MUSIC - 32-BIT (x86) PORTABLE EDITION
==================================================

Welcome to Astra Music for Windows 32-bit (x86)!
Because modern Flutter engines only distribute native 64-bit binaries,
this portable edition provides:
1. Instant Progressive Web App (PWA) desktop integration.
2. WebAssembly audio processing.
3. Offline local audio playback and waveform studio tools.

INSTRUCTIONS:
- Double click 'Launch-AstraMusic.bat' to launch the app in your browser or desktop window.
- In Edge or Chrome, click the 'Install Astra Music' button in the URL bar to pin it to your desktop taskbar.
