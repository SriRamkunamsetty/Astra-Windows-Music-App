@echo off
title Astra Music 32-Bit
echo Launching Astra Music...
start https://astramusic.app/
exit
